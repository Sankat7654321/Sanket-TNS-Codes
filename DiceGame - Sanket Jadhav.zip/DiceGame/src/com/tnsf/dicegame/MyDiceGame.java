package com.tnsf.dicegame;

import java.util.Random;
import java.util.Scanner;

public class MyDiceGame {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        System.out.println("Welcome to the Dice Game!");
        System.out.println("Press 'R' to roll the dice or 'Q' to quit.");

        while (true) {
            System.out.print("Enter your choice: ");
            String input = scanner.nextLine().trim().toUpperCase();

            if (input.equals("Q")) {
                System.out.println("Thanks for playing! Goodbye!");
                break;
            } else if (input.equals("R")) {
                // Roll two dice
                int dice1 = random.nextInt(6) + 1; // Random number between 1 and 6
                int dice2 = random.nextInt(6) + 1;
                int sum = dice1 + dice2;

                System.out.println("You rolled: " + dice1 + " and " + dice2);
                System.out.println("Total: " + sum);

                // Simple game logic
                if (sum == 7) {
                    System.out.println("Lucky 7! You win!");
                } else if (sum == 2) {
                    System.out.println("Snake eyes! You lose!");
                } else {
                    System.out.println("Try again!");
                }
            } else {
                System.out.println("Invalid input. Please press 'R' to roll or 'Q' to quit.");
            }
        }

        scanner.close();
    }
}