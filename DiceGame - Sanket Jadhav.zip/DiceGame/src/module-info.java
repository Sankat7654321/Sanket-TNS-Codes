/**
 * 
 */
/**
 * 
 */
module DiceGame {
}