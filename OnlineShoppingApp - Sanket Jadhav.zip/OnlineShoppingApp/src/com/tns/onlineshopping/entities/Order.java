package com.tns.onlineshopping.entities;

public class Order {

	public String getStatus() {
		// TODO Auto-generated method stub
		return null;
	}

	public int getOrderId() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void setStatus(String status) {
		// TODO Auto-generated method stub
		
	}

	public ProductQuantityPair[] getProducts() {
		// TODO Auto-generated method stub
		return null;
	}

}
